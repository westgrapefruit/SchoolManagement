package com.swpu.serviceIpml;

import com.swpu.dao.ClassManagementDao;
import com.swpu.dao.CourseManagementDao;
import com.swpu.dao.GradesManagementDao;
import com.swpu.pojo.Course;
import com.swpu.pojo.SC;
import com.swpu.pojo.Student;
import com.swpu.pojo.Teacher;
import com.swpu.service.IGradesManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GradesManagementServiceImpl implements IGradesManagementService {

    @Autowired
    GradesManagementDao gradesManagementDao;

    @Autowired
    ClassManagementDao classManagementDao;

    @Autowired
    CourseManagementDao courseManagementDao;


    @Override
    public int deleteGradesInformation(SC sc) {
        return gradesManagementDao.deleteGradesInformation(sc);
    }

    @Override
    public int editGradesInformation(SC sc) {
        return gradesManagementDao.editGradesInformation(sc);
    }

    @Override
    public int addGradesInformation(SC sc) {
        return gradesManagementDao.addGradesInformation(sc);
    }

    /**
     * 查询全部成绩
     * @return 成绩信息
     */
    @Override
    public List<SC> queryAllGradesInformation() {
        List<SC> allGrades = gradesManagementDao.queryAllGradesInformation();
        return allGrades;
    }

    @Override
    public List<SC> queryGradesBySnoAndCnoAndTnoAndClassno(SC sc) {
        return gradesManagementDao.queryGradesBySnoAndCnoAndTnoAndClassno(sc);
    }

    @Override
    public List<SC> queryGradesForTeacher(Teacher t) {
        return gradesManagementDao.queryGradesForTeacher(t);
    }

    @Override
    public List<SC> queryGradesForStudent(Student s) {
        return gradesManagementDao.queryGradesForStudent(s);
    }


}
