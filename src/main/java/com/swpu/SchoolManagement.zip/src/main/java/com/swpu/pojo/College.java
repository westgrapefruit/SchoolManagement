package com.swpu.pojo;

public class College {
    private String[] colleges;//学院名

    public String[] getColleges() {
        return colleges;
    }

    public void setColleges(String[] colleges) {
        this.colleges = colleges;
    }
}
