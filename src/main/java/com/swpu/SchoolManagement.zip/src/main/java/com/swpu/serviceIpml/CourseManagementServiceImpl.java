package com.swpu.serviceIpml;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.swpu.dao.CourseManagementDao;
import com.swpu.pojo.Course;
import com.swpu.pojo.Student;
import com.swpu.pojo.Teacher;
import com.swpu.service.ICourseManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class CourseManagementServiceImpl implements ICourseManagementService {
    @Autowired
    CourseManagementDao courseManagementDao;

    @Override
    public List<Course> queryAllLearnCourse(Student student) {
        return courseManagementDao.queryAllLearnCourse(student);
    }

    @Override
    public List<Course> queryCourseByCnoAndSno(Student student, Course course) {
        return courseManagementDao.queryCourseByCnoAndSno(student,course);
    }

    @Override
    public List<Course> queryCourseByCnoAndTno(Teacher teacher, Course course) {
        return courseManagementDao.queryCourseByCnoAndTno(teacher, course);
    }

    @Override
    public List<Course> queryAllTeachCourse(Teacher teacher) {
        return courseManagementDao.queryAllTeachCourse(teacher);
    }

    @Override
    public int editCourseInformation(Course course) {
        return courseManagementDao.editCourseInformation(course);
    }

    @Override
    public List<Course> queryCourseByCno(Course course) {
        return courseManagementDao.queryCourseByCno(course);
    }

    @Override
    public List<Course> queryCourseByCname(Course course) {
        return courseManagementDao.queryCourseByCname(course);
    }

    @Override
    public List<Course> queryCourseByCnoAndCName(Course course) {
        return courseManagementDao.queryCourseByCnoAndCName(course);
    }

    @Override
    public HashMap<String, Object> queryAllCourseInformation(Course course) {
        HashMap<String, Object> map = new HashMap<>();
        //使用分页插件
        //1、设置分页参数
        PageHelper.startPage(course.getPage(), course.getRow());
        List<Course> list = new ArrayList<>();

        //判断用户输入的查询是否有值
        if(course.getConValue().equals("")){

            //list = userInfoDao.select();
            //判断redis缓存中是否有数据
            //String key = "wen";
            //Object o = redisTemplate.opsForValue().get(key);
            //if(o==null){
            //    //第一次进入，查询mysql数据库
            //    list = userInfoDao.select();
            //    //存入到缓存中
            //    redisTemplate.opsForValue().set(key,list,10, TimeUnit.MINUTES);
            //}else{
            //    //取出缓存中的数据
            //    list = (List<UserInfo>)o;
            //}


        }else{
            //根据用户选择的查询条件判断用户需要查询的
            if (course.getCondition().equals("编号")) {
                //进行编号查询
                //设置用户选择的查询条件
                course.setCno(course.getConValue());
                list = courseManagementDao.queryCourseByCno(course);
            } else if (course.getCondition().equals("课程名")) {
                course.setCname(course.getConValue());
                list = courseManagementDao.queryCourseByCname(course);
            } else {
                //2、查询数据表数据
                list = courseManagementDao.queryAllCourseInformation();
            }
        }
        //3、把查询的数据转化成分页对象
        PageInfo<Course> page = new PageInfo<>(list);

        //获取分页的当前页的集合
        map.put("list", page.getList());
        //总条数
        map.put("total", page.getTotal());
        //总页数‘
        map.put("totalPage", page.getPages());
        //上一页
        if (page.getPrePage() == 0) {
            map.put("prePage", 1);
        } else {
            map.put("prePage", page.getPrePage());
        }

        //下一页

        if (page.getNextPage() == 0) {
            map.put("nextPage", page.getPages());
        } else {
            map.put("nextPage", page.getNextPage());
        }

        map.put("currentPage", page.getPageNum());
        map.put("currentPageSize", page.getSize());

        return map;
    }

    @Override
    public int deleteCourseInformation(Course course) {
        return courseManagementDao.deleteCourseInformation(course);
    }

    @Override
    public int addCourseInformation(Course course) {
        return courseManagementDao.addCourseInformation(course);
    }
}
