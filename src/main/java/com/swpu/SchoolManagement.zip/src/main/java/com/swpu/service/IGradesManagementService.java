package com.swpu.service;

import com.swpu.pojo.SC;
import com.swpu.pojo.Student;
import com.swpu.pojo.Teacher;

import java.util.List;

public interface IGradesManagementService {
    int deleteGradesInformation(SC sc);

    int editGradesInformation(SC sc);

    int addGradesInformation(SC sc);

    List<SC> queryAllGradesInformation();

    List<SC> queryGradesBySnoAndCnoAndTnoAndClassno(SC sc);

    List<SC> queryGradesForTeacher(Teacher t);

    List<SC> queryGradesForStudent(Student s);

}
