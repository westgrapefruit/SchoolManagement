import com.swpu.util.PasswordConverter;

import java.util.HashMap;

public class Test {
    public static void main(String[] args) {

    }
}
